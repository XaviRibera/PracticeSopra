export interface cardDescription {
  title: string;
  img: string;
  description: string;
}
