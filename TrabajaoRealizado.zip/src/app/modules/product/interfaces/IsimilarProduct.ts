import { Iproduct } from "./Iproduct";

export interface IsimilarProduct extends Iproduct{

}
