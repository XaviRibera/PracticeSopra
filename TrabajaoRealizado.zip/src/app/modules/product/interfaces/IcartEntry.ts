import { DetailProduct } from "./models/DetailProduct";

export interface IcartEntry {
  product: DetailProduct;
  quantity: number;
}
