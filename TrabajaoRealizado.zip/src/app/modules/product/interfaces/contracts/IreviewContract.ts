export interface IreviewContract {
  image:string;
  name:string;
  rating:number;
  opinion:string;
  date:string;
}
